module.exports = bot => {
    // Checks when a message is sent by the player at all
    bot.on('chat', (username, message) => {
        // player defs (unused)
        const playerid = 'user';
        const playermessage = 'hello';
        var infractions = 0;
        var userid = bot.players[null]
        // Checks for commands in a string.
        switch (message) {
            case (message == 'tp'):
                // Teleports the bot to the player!
                if (bot.players[username].entity) {
                    bot.entity.position.set(bot.players[username].entity.position.x, bot.players[username].entity.position.y, bot.players[username].entity.position.z)
                }
                if (!bot.players[username].entity) {
                    bot.chat("I can't see you!")
                    return
                }
                break
            case (message == 'locate '):
                const xPos = message.split(" ")[1]
                const yPos = message.split(" ")[2]
                const zPos = message.split(" ")[3]
                // Creates a movement system to go to the user
                const defaultMove = new Movements(bot)
                bot.pathfinder.setMovements(defaultMove)
                bot.pathfinder.setGoal(new GoalNear(xPos, yPos, zPos))
                break
            case (message == 'position'):
                // Teleports the bot to the player!
                if (bot.players[username].entity) {
                    bot.chat(`I am at ${bot.entity.position}`)
                    bot.chat(`You are at ${bot.players[username].entity.position}`)
                }
                if (!bot.players[username].entity) {
                    bot.chat("I can't see you!")
                    return
                }
                break
        }
    })
}