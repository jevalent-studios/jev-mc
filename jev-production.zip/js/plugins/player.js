module.exports = bot => {
    var servername = process.env.SERVERNAME
    // Listens for when the bot dies
    bot.on('death', () => {
        if (!bot.username) {
            return
        }
        if (bot.username) {
            bot.chat('I died')
        }
    })
    // Listens for when a player dies
    bot.on('entityDead', (player) => {
        if (player.username == bot.username) {
            return
        }
        if (!player) {
            return
        }
        if (player.type == 'player') {
            bot.chat(player.username + " died! That sucks.")
        }
    })
    // Listens for when a player joins the game.
    bot.on('playerJoined', (player) => {
        if (player.username !== bot.username) {
            bot.chat(`Hello, ${player.username}! Welcome to ${servername}.`)
        }
    })
    // Listens for when a player leaves the game.
    bot.on('playerLeft', (player) => {
        if (player.username === bot.username) return
        bot.chat(`Bye ${player.username}. Hope to see you again soon on ${servername}!`)
    })
}