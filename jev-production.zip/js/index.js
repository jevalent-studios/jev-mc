/*
-----------------------
|       JevMC V2      |
|Developed by Jevalent|
| See README for more |
|     information     |
|      Thank you!     |
-----------------------
*/

const mineflayer = require('mineflayer')
const { Vec3 } = require('vec3')
const env = require("dotenv").config()
const { pathfinder, Movements, goals: { GoalNear }, goals } = require('mineflayer-pathfinder')
const GoalFollow = goals.GoalFollow
const GoalBlock = goals.GoalBlock
const collectBlockPlugin = require('mineflayer-collectblock').plugin
const pvp = require('mineflayer-pvp').plugin
const fs = require("fs")

// Creates the bot with the command line agruments or with the .env
const bot = mineflayer.createBot({
    plugins: {
        detect: require("./plugins/player"),
        tp: require("./plugins/teleport"),
        interact: require("./plugins/interact")
    },
    host: process.env.HOSTNAME || process.argv[0],
    username: process.env.NAME || process.argv[1],
    password: process.env.PASSWORD || process.argv[2] || "",
    port: process.env.PORT || process.argv[3],
})

// Loads each plugin
bot.loadPlugin(pathfinder)
bot.loadPlugin(pvp)
bot.on('resourcePack', () => { // Accepts resource pack sent by server
    bot.acceptResourcePack()
})
console.log(process.env) // This is for debugging

// current timestamp in milliseconds
let ts = Date.now();

var servername = process.env.SERVERNAME
// Checks the time in UTC
let date_ob = new Date(ts);
let date = date_ob.getDate();
let month = date_ob.getMonth() + 1;
let year = date_ob.getFullYear();
let hour = date_ob.getHours()
let minutes = date_ob.getMinutes();
let fullDate = year + "-" + month + '-' + date
let fullTime = hour + ':' + minutes
// Function for finding a bed and sleeping in it.
async function goToSleep() {
    const bed = bot.findBlock({
        matching: block => bot.isABed(block)
    })
    if (bed) {
        try {
            await bot.sleep(bed)
            bot.chat("I'm sleeping")
        } catch (err) {
            bot.chat(`I can't sleep: ${err.message}`)
        }
    } else {
        bot.chat('No nearby bed')
    }
}
//Function for locating an emerald block and moving to it
function locateEmeraldBlock() {
    const mcData = require('minecraft-data')(bot.version)
    const movements = new Movements(bot, mcData)
    movements.scafoldingBlocks = []
    bot.pathfinder.setMovements(movements)

    const emeraldBlock = bot.findBlock({
        matching: mcData.blocksByName.emerald_block.id,
        maxDistance: 100
    })

    if (!emeraldBlock) {
        bot.chat("I can't see any emerald blocks!")
        return
    }

    const x = emeraldBlock.position.x
    const y = emeraldBlock.position.y + 1
    const z = emeraldBlock.position.z
    const goal = new GoalBlock(x, y, z)
    bot.pathfinder.setGoal(goal)
}
// Checks when a message is sent by the player at all
bot.on('chat', (username, message) => {
    // player defs (unused)
    const playerid = 'user';
    const playermessage = 'hello';
    var infractions = 0;
    var userid = bot.players[null]
    // Checks for commands in a string.
    switch (true) {
        // Checks if the user is saying "hi"
        case (message == 'hi'):
            bot.chat('hello, nice to meet you ', username)
            break
        // Checks if the user is asking for a joke
        case (message == 'tell me a joke'):
            var joke = Math.floor(Math.random() * 6) + 1;
            var jokeresult = 0;
            switch (joke) {
                case (joke = 1):
                    jokeresult = 'What do you call a fish without eyes? Fsh.'
                    break
                case (joke = 2):
                    jokeresult = 'What do you call an alligator detective? An investi-gator.'
                    break
                case (joke = 3):
                    jokeresult = 'Why did the scarecrow win an award? Because he was outstanding in his field.'
                    break
                case (joke = 4):
                    jokeresult = 'What lights up a soccer stadium? A soccer match.'
                    break
                case (joke = 5):
                    jokeresult = 'no'
                    break
            }
            bot.chat(jokeresult)
            break
        // Checks if the user is telling the bot to shut, you're mean!
        case (message == 'shut up'):
            bot.chat("That isn't very nice :(")
            break
        // Checks if the user is saying "who asked?"
        case (message == 'who asked?'):
            bot.chat("nobody.")
            break
        // Checks if the user is asking for the bot's position
        case (message == "where are you?"):
            // Tells the user their position
            bot.chat(`I am at ${bot.entity.position}`)
            // Checks if the nearest entity is there or not
            if (!bot.players[username].entity) {
                bot.chat("I cannot see you!")
                return
            }
            if (bot.players[username].entity.position) {
                bot.chat(`You are at ${bot.players[username].entity.position}`)
            }
            break
        case (message == "track"):
            // Defines the nearest entity
            const entity = bot.nearestEntity()
            // Checks if the entity is a player or mob.
            if (entity.type === 'player') {
                bot.chat(`Player: ${entity.username} is at ${entity.position}`)
            }
            if (entity.type === 'mob') {
                bot.chat(`Entity: ${entity.type} is at ${entity.position}`)
            }
            break
        case (message == 'what is the time?'):
            // Checks if the time of day is less than 101 ticks, if not than display the time as normal.
            if (bot.time.timeOfDay < 101) {
                bot.chat("it's muffin time!")
            } else {
                bot.chat('The time is ' + bot.time.timeOfDay)
            }
            break
        case (message == 'what is the actual date?'):
            // Checks the date in real-time based on the bot's timezone (aka the user who is running the bot)
            bot.chat('The date is ' + fullDate)
            break
        case (message == 'sleep'):
            // Broadcasts the sleep function.
            goToSleep()
            break
        case (message == 'what is the actual time?'):
            // Checks the time in real-time.
            bot.chat('The time is ' + fullTime)
            break
        case (message == 'tell me a fun fact'):
            // Generate a random int.
            var fact = Math.floor(Math.random() * 3 + 1);
            // Sets the fact string to 0 to prevent repeated phrases (Still doesn't fully work)
            var factresult = 0;
            switch (fact) {
                case (fact = 1):
                    factresult = "Fun fact: If my name is Jev, wouldn't I be a jeveloper?"
                    break
                case (fact = 2):
                    factresult = "Fun fact: All sad anime eyes are just amogi wearing shoes"
                    break
                case (fact = 3):
                    factresult = "Fun Fact: In minecraft, where did they get the panda death sound from?"
                    break
            }
            bot.chat(factresult)
            break
        case (message == 'tp'):
            // Teleports the bot to the player!
            if (bot.players[username].entity) {
                bot.entity.position.set(bot.players[username].entity.position.x, bot.players[username].entity.position.y, bot.players[username].entity.position.z)
            }
            if (!bot.players[username].entity) {
                bot.chat("I can't see you!")
                return
            }
            break
        case (message == 'tell me about something'):
            var wikipedia = Math.floor(Math.random() * 3)
            var wikipediaresult = 0;
            switch (wikipedia) {
                case (wikipedia = 1):
                    wikipediaresult = "Roblox is an online game platform and game creation system developed by Roblox Corporation that allows users to program games and play games created by other users. Created by David Baszucki and Erik Cassel in 2004 and released in 2006, the platform hosts user-created games of multiple genres coded in the programming language Lua. "
                    break
                case (wikipedia = 2):
                    wikipediaresult = "Satisfactory is a factory simulation game created by Swedish video game developer Coffee Stain Studios. It is a 3D first-person open world exploration and factory building game. The player, a pioneer, is dropped onto an alien planet with a handful of tools and must harvest the planet's natural resources to construct increasingly complex factories for automating all resource needs. "
                    break
                case (wikipedia = 3):
                    wikipediaresult = "Rainbow Friends is a Roblox horror experience that joins games like Piggy, Five Nights at Freddy's, Poppy Playtime, and others, in taking something seemingly nice and friendly and turning it into a terrifying nightmare."
                    break
            }
            bot.chat(wikipediaresult)
            break
        case (message == "go"):
            if (username !== bot.username) {
                    // Creates a movement system to go to the user
                    const defaultMove = new Movements(bot)
                    const target = bot.players[username]?.entity
                    if (!target) {
                        bot.chat("I don't see you !")
                        return
                    }
                    const { x: playerX, y: playerY, z: playerZ } = target.position
                    bot.pathfinder.setMovements(defaultMove)
                    bot.pathfinder.setGoal(new GoalNear(playerX, playerY, playerZ))
            }
            break
        case (message == "find"):
            if (username !== bot.username) {
                locateEmeraldBlock()
            }
            break
        case (message == "look"):
            const playerFilter = (entity) => entity.type === 'player'
            const playerEntity = bot.nearestEntity(playerFilter)

            if (!playerEntity) return

            const pos = playerEntity.position.offset(0, playerEntity.height, 0)
            bot.lookAt(pos)
            break
    }
})

// Log errors and kick reasons:
bot.on('kicked', console.log)
bot.on('error', console.log)