-----------------------
|       JevMC V2      |
|Developed by Jevalent|
|      Thank you!     |
-----------------------

Hello, I'm Jevalent! I created and developed JevMC, creative name, right?

Please take a look at the features and things that JevMC can do!

If you have any questions, comments, or anything you want to contribute to feel free to say/do so on our GitHub:

GitHub Repo: https://github.com/jevalent-studios/jev-mc

Features:

Implemented:
Interact with blocks
Detect when a player leaves, joins, or dies.
Teleports to players and entities

Uninplemented:
Attack/guarding the player or entities
Collecting blocks and items
Organizing Inventory
Support for ^1.19.1

How to add plugins:
In the values under "plugins" require a module in anything under the "plugins" directory, an example would be:
// Creates the bot with the command line agruments or with the .env
const bot = mineflayer.createBot({
    plugins: {
        detect: require("./plugins/player"),
        tp: require("./plugins/teleport"),
        interact: require("./plugins/interact")
    },
    host: process.env.HOSTNAME || process.argv[0],
    username: process.env.NAME || process.argv[1],
    password: process.env.PASSWORD || process.argv[2] || "",
    port: process.env.PORT || process.argv[3],
})